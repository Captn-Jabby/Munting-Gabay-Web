Please extract and copy the Firebase SDK inside the folder of the Web-Application
